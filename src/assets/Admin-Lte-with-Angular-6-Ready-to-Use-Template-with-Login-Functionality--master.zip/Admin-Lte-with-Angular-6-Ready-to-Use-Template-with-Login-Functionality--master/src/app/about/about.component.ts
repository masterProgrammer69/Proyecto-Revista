import { Component } from '@angular/core';

@Component ({
   selector: 'app-header-component',
   templateUrl: '/about.component.html',
})
export class AboutComponent  {
    
}